### Hexlet tests and linter status:
[![Actions Status](https://github.com/DyakonovVitaliy/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DyakonovVitaliy/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/0a1af83ff73b41fdfabb/maintainability)](https://codeclimate.com/github/DyakonovVitaliy/python-project-49/maintainability)

https://asciinema.org/a/oXXvXQcq6e6x64IavDqAY6aOh

https://asciinema.org/a/yXE2WUaX2gtKIoZQ5nVrWtHeQ

https://asciinema.org/a/TYIRF8d0WbIgSmpQiPrPiat0f

https://asciinema.org/a/JiJ3RI9fj4hDmxLQKjnDeIK5Z

https://asciinema.org/a/IWxUvp1ArlJN23Q4rdD0gnqOz